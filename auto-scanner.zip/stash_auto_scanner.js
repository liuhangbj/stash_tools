/**
 * Auto Scanner - UI 增强脚本
 * 在场景详情页添加「重新生成NFO」按钮
 */

(function() {
    'use strict';
    
    const PLUGIN_ID = 'auto-scanner';
    
    // 检查是否在场景页面
    function isScenePage() {
        return window.location.hash.startsWith('#/scenes/') || 
               document.querySelector('.scene-details') !== null;
    }
    
    // 获取当前场景ID
    function getSceneId() {
        // 从 URL 提取
        const match = window.location.hash.match(/\/scenes\/(\d+)/);
        if (match) return match[1];
        
        // 从页面元素提取
        const idElement = document.querySelector('[data-scene-id]');
        if (idElement) return idElement.getAttribute('data-scene-id');
        
        return null;
    }
    
    // 创建按钮
    function createRegenerateButton() {
        const button = document.createElement('button');
        button.className = 'btn btn-primary btn-sm ml-2';
        button.innerHTML = '📝 重新生成NFO';
        button.style.cssText = 'margin-left: 8px;';
        button.onclick = async function() {
            const sceneId = getSceneId();
            if (!sceneId) {
                alert('无法获取场景ID');
                return;
            }
            
            button.disabled = true;
            button.innerHTML = '⏳ 生成中...';
            
            try {
                // 调用 GraphQL mutation 触发插件任务
                const response = await fetch('/graphql', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        query: `
                            mutation RunPluginTask {
                                runPluginTask(
                                    plugin_id: "${PLUGIN_ID}",
                                    task_name: "重新生成NFO",
                                    args: { scene_id: "${sceneId}" }
                                )
                            }
                        `
                    })
                });
                
                const result = await response.json();
                if (result.data && result.data.runPluginTask) {
                    button.innerHTML = '✅ 已生成';
                    setTimeout(() => {
                        button.innerHTML = '📝 重新生成NFO';
                        button.disabled = false;
                    }, 2000);
                } else {
                    throw new Error('GraphQL error');
                }
            } catch (e) {
                button.innerHTML = '❌ 失败';
                console.error('NFO生成失败:', e);
                setTimeout(() => {
                    button.innerHTML = '📝 重新生成NFO';
                    button.disabled = false;
                }, 2000);
            }
        };
        return button;
    }
    
    // 在场景操作栏添加按钮
    function addButtonToScenePage() {
        if (!isScenePage()) return;
        
        // 等待页面加载
        setTimeout(() => {
            // 查找操作按钮栏（保存/删除按钮附近）
            const actionBar = document.querySelector('.scene-details .btn-toolbar, .scene-page .btn-toolbar, .details-page .btn-toolbar');
            if (!actionBar) return;
            
            // 检查是否已添加
            if (actionBar.querySelector('[data-auto-scanner-btn]')) return;
            
            const button = createRegenerateButton();
            button.setAttribute('data-auto-scanner-btn', 'true');
            actionBar.appendChild(button);
        }, 500);
    }
    
    // 监听页面变化
    const observer = new MutationObserver(function(mutations) {
        if (isScenePage()) {
            addButtonToScenePage();
        }
    });
    
    // 启动监听
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
    
    // 初始检查
    if (isScenePage()) {
        addButtonToScenePage();
    }
    
    console.log('[Auto Scanner] UI 脚本已加载');
})();
