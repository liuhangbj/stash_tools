/**
 * Auto Scanner - UI 增强脚本
 * 在场景详情页添加「重新生成NFO」按钮
 */

(function() {
    'use strict';
    
    const PLUGIN_ID = 'auto-scanner';
    let buttonAdded = false;
    
    // 获取当前场景ID
    function getSceneId() {
        // 从 URL 提取
        const match = window.location.hash.match(/\/scenes\/(\d+)/);
        if (match) return match[1];
        
        // 从页面元素提取
        const idElement = document.querySelector('[data-scene-id]');
        if (idElement) return idElement.getAttribute('data-scene-id');
        
        return null;
    }
    
    // 创建按钮
    function createRegenerateButton() {
        const button = document.createElement('button');
        button.className = 'btn btn-secondary btn-sm';
        button.innerHTML = '📝 生成NFO';
        button.style.cssText = 'margin-left: 8px;';
        button.onclick = async function() {
            const sceneId = getSceneId();
            if (!sceneId) {
                alert('无法获取场景ID');
                return;
            }
            
            button.disabled = true;
            button.innerHTML = '⏳ 生成中...';
            
            try {
                const response = await fetch('/graphql', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        query: `mutation RunPluginTask {
                            runPluginTask(
                                plugin_id: "${PLUGIN_ID}",
                                task_name: "重新生成NFO",
                                args: { scene_id: "${sceneId}" }
                            )
                        }`
                    })
                });
                
                const result = await response.json();
                if (result.data && result.data.runPluginTask) {
                    button.innerHTML = '✅ 已生成';
                    setTimeout(() => {
                        button.innerHTML = '📝 生成NFO';
                        button.disabled = false;
                    }, 2000);
                } else {
                    throw new Error('GraphQL error');
                }
            } catch (e) {
                button.innerHTML = '❌ 失败';
                console.error('NFO生成失败:', e);
                setTimeout(() => {
                    button.innerHTML = '📝 生成NFO';
                    button.disabled = false;
                }, 2000);
            }
        };
        return button;
    }
    
    // 查找操作栏 - 尝试多种选择器
    function findActionBar() {
        // 尝试多种可能的选择器
        const selectors = [
            '.scene-details .btn-toolbar',
            '.scene-page .btn-toolbar', 
            '.details-page .btn-toolbar',
            '[class*="scene"] [class*="toolbar"]',
            '[class*="scene"] .btn-group',
            '.card-header .btn-toolbar',
            // Stash 新版 UI
            'button[title="Edit"]', // 编辑按钮附近
            'button[title="Delete"]', // 删除按钮附近
        ];
        
        for (const selector of selectors) {
            const el = document.querySelector(selector);
            if (el) {
                // 如果是单个按钮，返回其父容器
                if (el.tagName === 'BUTTON') {
                    return el.parentElement;
                }
                return el;
            }
        }
        return null;
    }
    
    // 添加按钮到场景页面
    function addButtonToScenePage() {
        if (buttonAdded) return;
        
        const sceneId = getSceneId();
        if (!sceneId) return;
        
        const actionBar = findActionBar();
        if (!actionBar) return;
        
        // 检查是否已添加
        if (actionBar.querySelector('[data-auto-scanner-btn]')) {
            buttonAdded = true;
            return;
        }
        
        const button = createRegenerateButton();
        button.setAttribute('data-auto-scanner-btn', 'true');
        actionBar.appendChild(button);
        buttonAdded = true;
        
        console.log('[Auto Scanner] NFO按钮已添加');
    }
    
    // 监听页面变化
    const observer = new MutationObserver(function(mutations) {
        // 检查是否在场景页面
        if (window.location.hash.includes('/scenes/')) {
            addButtonToScenePage();
        } else {
            buttonAdded = false;
        }
    });
    
    // 启动监听
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
    
    // 初始检查
    if (window.location.hash.includes('/scenes/')) {
        setTimeout(addButtonToScenePage, 1000);
    }
    
    console.log('[Auto Scanner] UI 脚本已加载');
})();
